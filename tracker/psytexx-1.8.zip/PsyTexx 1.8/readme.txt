--------------------------PsyTexx---------------------------
---------------------Amiga MOD Tracker----------------------
                        for PalmOS5
----------------------------v1.8----------------------------
--------------------by Alexandr Zolotov---------------------

New in version 1.8 (19 jan 2005):
* five octaves instead of three (use a following keys: A,B,C);
* sample effects: anticlick, HQ-portamento, distortion, simple cut-off and wah-wah;
* additional pattern effects: 6xx, 7xx, 8xx;
* internal help;
* 12 channels;
* new sample interpolation.

New in version 1.5:
* surround echo (you can play MODs with echo in the PsyTexx only!);
* auto properties saving;
* new effects: E1x E2x EAx EBx;
* much more powerfull sample editor (use menu for the new features);
* playing to the copy-buffer (for sample editor);
* 16bit linear interpolation;
* now you can play MODs in Palm SIMULATOR: just put win32DLL.dll file to the folder with Simulator and use psytexx_sim.prc;
* if you want to play MOD without additional effects (like an echo) press the CLASSIC MOD PLAYING button.

New in version 1.3:
* 8 channels support;
* 16 bit mixing;
* stereo sound;
* fixed some bugs in player;
* changed gui;
* new supported effects: Axx;
* and other small improvements... :)

                     www.warmplace.ru
                2004. Ekaterinburg. Russia.
