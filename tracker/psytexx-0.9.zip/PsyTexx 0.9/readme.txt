--------------------------PsyTexx---------------------------
---------------------Amiga MOD Tracker----------------------
---------------------------v0.9-----------------------------
--------------------by Alexandr Zolotov---------------------
    (need Javu sound driver:http://www.shin.nu/~FocV/)

                     www.warmplace.ru
                2002. Ekaterinburg. Russia.
